<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?></title>

	<link href="//www.google-analytics.com" rel="dns-prefetch">
	<link href="<?php echo get_template_directory_uri(); ?>/img/icons/favicon.ico" rel="shortcut icon">
	<link href="<?php echo get_template_directory_uri(); ?>/img/icons/touch.png" rel="apple-touch-icon-precomposed">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<!-- Bootstrap core CSS -->
	<link href="<?php bloginfo( 'template_directory' )?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

	<!-- Custom fonts for this template -->
	<link href="<?php bloginfo( 'template_directory' )?>/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

	<!-- Plugin CSS -->
	<link href="<?php bloginfo( 'template_directory' )?>/vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

	<!-- Custom styles for this template -->
	<link href="<?php bloginfo( 'template_directory' )?>/css/getMKG.css" rel="stylesheet">

	
	<script>
        // conditionizr.com
        // configure environment tests
        conditionizr.config({
        	assets: '<?php echo get_template_directory_uri(); ?>',
        	tests: {}
        });
    </script>

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="page-top">

	<!-- wrapper -->

		

		<!-- nav -->
		<nav class="navbar navbar-expand-lg navbar-light bg-faded fixed-top" id="mainNav">
			<div class="container">
				<a class="navbar-brand js-scroll-trigger" href="/">Meet Matt voran</a>
				<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarResponsive">
					<?php
					    wp_nav_menu( array(
					            'theme_location'    => 'header-menu',
					            'depth'             => 2,
					            'container'         => 'false',
					            'menu_class'        => 'nav ml-auto',
					            'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
					            'walker'            => new wp_bootstrap_navwalker())
					    );
					 ?>
				</div>
			</div>
		</nav><!-- /nav -->
		

<?php if( is_front_page()) { ?>

    <header class="masthead text-center text-white d-flex">
			<div class="container my-auto">
				<div class="row">
					<div class="col-lg-10 mx-auto">
						<h1 class="text-uppercase">
							<strong>Hi I'm Matt.<br> Nice to Meet You :)</strong>
						</h1>
						<hr>
					</div>
					<div class="col-lg-8 mx-auto">
						<h2 class="text-faded mb-5">I'm a Marketing and Strategy Executive <br> With a Coding Addiction</h2>
						<a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>
					</div>
				</div>
			</div>
		
		</header><!-- /header -->

<?php } else { ?> 

  <header class="masthead text-center text-white d-flex">
				<div class="container my-auto">
					<div class="row">
						<div class="col-lg-10 mx-auto">
							<h2 class="text-uppercase">
								<strong>interior header</strong>
							</h2>
							<hr>
						</div>
						<div class="col-lg-8 mx-auto">
							<p class="text-faded mb-5">interiot sub text</p>
							<a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>
						</div>
					</div>
				</div>
			</header><!-- /header -->';
  


<?php } ?>
