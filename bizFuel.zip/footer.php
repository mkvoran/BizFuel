			<!-- footer -->
			    <section id="footer" class="bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
           Footer
          </div>
        </div>
        <div class="row">
       
        </div>
      </div>
    </section>
			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

		<!-- analytics -->
	<!-- 	<script>
		(function(f,i,r,e,s,h,l){i['GoogleAnalyticsObject']=s;f[s]=f[s]||function(){
		(f[s].q=f[s].q||[]).push(arguments)},f[s].l=1*new Date();h=i.createElement(r),
		l=i.getElementsByTagName(r)[0];h.async=1;h.src=e;l.parentNode.insertBefore(h,l)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
		ga('send', 'pageview');
		</script> -->
    <!-- Bootstrap core JavaScript -->
    <script src="<?php bloginfo( 'template_directory' )?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php bloginfo( 'template_directory' )?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php bloginfo( 'template_directory' )?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?php bloginfo( 'template_directory' )?>/vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="<?php bloginfo( 'template_directory' )?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php bloginfo( 'template_directory' )?>/js/getMKG.min.js"></script>
	</body>
</html>
